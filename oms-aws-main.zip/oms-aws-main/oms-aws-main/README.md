# Order Management System

Production-oriented Go OMS: **API Gateway** (public) → **Order Service** + **Product Service** (private) → **PostgreSQL**. REST and GraphQL are exposed only through the gateway. HTTP only (terminate TLS at the load balancer in AWS).

## Architecture

```text
Client
  │ REST / GraphQL + Bearer JWT
  ▼
API Gateway (:8080)
  │ JWT, RBAC, metrics, request ID, security headers
  ▼
Order Service (:8081, private)
  │  pgx SQL repository
  │  resilient HTTP → Product Service
  ▼
Product Service (:8082, private) ──► PostgreSQL `products` catalog
  ▼
PostgreSQL (`orders`, `products`)
```

| Component | Responsibility |
| --- | --- |
| **Gateway** | Sole public entry; authenticates JWT; forwards REST/GraphQL to the order service; `/health/*`, `/metrics`. |
| **Order Service** | Four order operations, GraphQL, validation, SQL, DB + product dependency readiness. |
| **Product Service** | Reads unit prices from the `products` table (seeded at startup). |
| **PostgreSQL** | Schema + seed in `internal/database/`; applied automatically on service startup. |

Request correlation uses **`X-Request-ID`** and structured **span logs** (`span finished`) across handler → service → repository → PostgreSQL and the product HTTP client. See [docs/CLOUDWATCH.md](./docs/CLOUDWATCH.md) for AWS log/metric export.

## Prerequisites

- Go **1.25+**
- PostgreSQL **14+** (local or RDS)
- Copy [`.env.example`](./.env.example) to `.env` and set credentials (never commit `.env`).

### Create database and `.env`

```powershell
Copy-Item .env.example .env
# Set DB_USER, DB_PASSWORD, JWT_SECRET (≥ 32 bytes), and DB_NAME=oms
go run ./cmd/token -subject local-user -role customer   # after JWT_SECRET is set
```

Generate a JWT secret (PowerShell):

```powershell
$bytes = New-Object byte[] 48
[Security.Cryptography.RandomNumberGenerator]::Fill($bytes)
[Convert]::ToBase64String($bytes)
```

### Start locally (no containers)

Run PostgreSQL, then three terminals from the project root (all load `.env`):

```powershell
go run ./cmd/product-service
go run ./cmd/order-service
go run ./cmd/gateway
```

Verify:

- Liveness: `GET http://localhost:8080/health/live`
- Readiness: `GET http://localhost:8080/health/ready`
- Metrics: `GET http://localhost:8080/metrics`

Catalog seed products: **501** ($12.50), **502** ($49.99), **503** ($3.25).

## Configuration

| Variable | Purpose |
| --- | --- |
| `APP_PORT` | Gateway listen port (default `8080`) |
| `ORDER_SERVICE_*` | Order service port/URL |
| `PRODUCT_SERVICE_*` | Product service port/URL |
| `DB_*` | PostgreSQL connection (`DB_NAME` default `oms`) |
| `JWT_SECRET`, `JWT_TTL` | HS256 tokens (gateway + order service) |
| `PRODUCT_TIMEOUT`, `PRODUCT_MAX_RETRIES`, … | Client resilience (bounded retries, breaker) |
| `AWS_SECRETS_MANAGER_SECRET_ID`, `AWS_REGION` | Optional Secrets Manager JSON overlay |
| `CORS_ALLOWED_ORIGINS` | Optional comma-separated browser origins |

Secrets Manager JSON keys should match env names (e.g. `DB_PASSWORD`, `JWT_SECRET`). Existing env vars are not overwritten.

## Security

- **JWT** (HS256): `customer` — create/list/get; `admin` — plus status updates.
- **Gateway** enforces admin role on `PUT /api/v1/orders/{id}/status`; order service re-validates JWT on every route.
- Secure headers, optional CORS, parameterized SQL, capped JSON bodies, controlled error JSON with `requestId`.

### Test tokens

```powershell
go run ./cmd/token -subject local-user -role customer
go run ./cmd/token -subject local-admin -role admin
```

Use `Authorization: Bearer <token>` on all order and GraphQL calls through the gateway.

## REST API (via gateway)

| Method | Path | Role |
| --- | --- | --- |
| `POST` | `/api/v1/orders` | customer or admin |
| `GET` | `/api/v1/orders/{id}` | customer or admin |
| `GET` | `/api/v1/orders?limit=&offset=` | customer or admin |
| `PUT` | `/api/v1/orders/{id}/status` | **admin** |

Create:

```json
{"customerId":101,"productId":501,"quantity":2}
```

Status update:

```json
{"status":"CONFIRMED"}
```

Allowed statuses: `CREATED`, `CONFIRMED`, `CANCELLED`.

## GraphQL (via gateway)

`POST http://localhost:8080/graphql` with JSON body `{ "query": "...", "variables": { ... } }`.

Schema and examples: [`internal/orders/schema.graphqls`](./internal/orders/schema.graphqls).

## Testing

```powershell
gofmt -w .
go vet ./...
go test ./...
go test -race ./...
go test -tags=integration -race ./internal/orders/...   # needs Postgres + running product service
govulncheck ./...
```

CI runs the same checks (see [`.github/workflows/ci.yml`](./.github/workflows/ci.yml)).

**Note:** Tests were not executed in every environment; run the commands above locally to confirm.

## AWS deployment (Elastic Beanstalk, no Docker)

1. **RDS PostgreSQL** — create database `oms`, note host/user/password.
2. **Secrets Manager** — JSON secret with `DB_PASSWORD`, `JWT_SECRET`, etc.; set `AWS_SECRETS_MANAGER_SECRET_ID` on EB environments.
3. **Three EB applications** (Go platform, Amazon Linux 2023):
   - `oms-product-service` — artifact: `dist/product-service`, `deploy/product-service/Procfile`, `.ebextensions`, env `PRODUCT_SERVICE_PORT=8082`, DB vars, security group → RDS.
   - `oms-order-service` — `dist/order-service`, `PRODUCT_SERVICE_URL` → product EB internal URL, `ORDER_SERVICE_PORT=8081`.
   - `oms-gateway` — `dist/gateway`, `ORDER_SERVICE_URL` → order EB internal URL, `APP_PORT=8080`; attach public load balancer.
4. **CodeBuild** — use [`buildspec.yml`](./buildspec.yml) to compile Linux binaries and run tests/scans before deploy.
5. **CloudWatch** — [docs/CLOUDWATCH.md](./docs/CLOUDWATCH.md).

Keep order and product tiers in private subnets; only the gateway load balancer should be internet-facing.

## Troubleshooting

| Symptom | Check |
| --- | --- |
| `JWT_SECRET must contain at least 32 bytes` | Set secret in `.env` or Secrets Manager |
| Readiness 503 | Postgres up, seed applied, product service reachable from order service |
| `product service unavailable` | Product EB/URL, breaker state, logs with `request_id` |
| Create order fails on product | Use product IDs **501–503** or insert into `products` |

## Known limitations

- No per-customer order ownership (case study scope).
- GraphQL Playground not bundled; use any GraphQL HTTP client.
- Full OpenTelemetry exporters not included; use request ID + span logs and CloudWatch/Prometheus as documented.
