package product

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"sync/atomic"
	"testing"
	"time"

	"oms/internal/config"
)

func TestCircuitBreakerOpensAndRecovers(t *testing.T) {
	now := time.Now()
	breaker := &circuitBreaker{threshold: 2, recovery: time.Second}
	if !breaker.allow(now) {
		t.Fatal("new breaker should allow requests")
	}
	breaker.record(false, now)
	breaker.record(false, now)
	if breaker.allow(now) {
		t.Fatal("breaker should be open after threshold")
	}
	if !breaker.allow(now.Add(2 * time.Second)) {
		t.Fatal("breaker should allow a half-open probe after recovery")
	}
	if breaker.allow(now.Add(2 * time.Second)) {
		t.Fatal("breaker should allow only one half-open probe")
	}
	breaker.record(true, now.Add(2*time.Second))
	if !breaker.allow(now.Add(2 * time.Second)) {
		t.Fatal("breaker should close after a successful probe")
	}
}

func TestClientRetriesAreBoundedAndOpenBreaker(t *testing.T) {
	var calls atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		calls.Add(1)
		w.WriteHeader(http.StatusServiceUnavailable)
	}))
	defer server.Close()
	client, err := NewClient(config.Config{
		ProductServiceURL:   server.URL,
		ProductTimeout:      100 * time.Millisecond,
		ProductMaxRetries:   2,
		ProductRetryBase:    time.Millisecond,
		ProductBreakerLimit: 1,
		ProductBreakerWait:  time.Second,
	})
	if err != nil {
		t.Fatal(err)
	}
	if _, err := client.Price(context.Background(), 501); !errors.Is(err, ErrUnavailable) {
		t.Fatalf("expected controlled dependency error, got %v", err)
	}
	if got := calls.Load(); got != 3 {
		t.Fatalf("request attempts = %d, want initial request plus two retries", got)
	}
	if _, err := client.Price(context.Background(), 501); !errors.Is(err, ErrUnavailable) {
		t.Fatalf("expected open breaker to reject request, got %v", err)
	}
	if got := calls.Load(); got != 3 {
		t.Fatalf("open breaker made another request: total calls = %d", got)
	}
}

func TestClientDoesNotRetryNonTransientResponse(t *testing.T) {
	var calls atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		calls.Add(1)
		w.WriteHeader(http.StatusBadRequest)
	}))
	defer server.Close()
	client, err := NewClient(config.Config{
		ProductServiceURL:   server.URL,
		ProductTimeout:      100 * time.Millisecond,
		ProductMaxRetries:   3,
		ProductRetryBase:    time.Millisecond,
		ProductBreakerLimit: 1,
		ProductBreakerWait:  time.Second,
	})
	if err != nil {
		t.Fatal(err)
	}
	if _, err := client.Price(context.Background(), 501); !errors.Is(err, ErrUnavailable) {
		t.Fatalf("expected controlled dependency error, got %v", err)
	}
	if got := calls.Load(); got != 1 {
		t.Fatalf("non-transient response retried %d times, want 1", got)
	}
	if _, err := client.Price(context.Background(), 501); !errors.Is(err, ErrUnavailable) {
		t.Fatalf("unexpected second call error: %v", err)
	}
	if got := calls.Load(); got != 2 {
		t.Fatalf("non-transient response incorrectly opened breaker: total calls = %d", got)
	}
}

func TestClientHonorsPerAttemptTimeout(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		select {
		case <-r.Context().Done():
		case <-time.After(time.Second):
			w.WriteHeader(http.StatusOK)
			_, _ = w.Write([]byte(`{"productId":501,"price":12.5}`))
		}
	}))
	defer server.Close()
	client, err := NewClient(config.Config{
		ProductServiceURL:   server.URL,
		ProductTimeout:      25 * time.Millisecond,
		ProductMaxRetries:   0,
		ProductRetryBase:    time.Millisecond,
		ProductBreakerLimit: 2,
		ProductBreakerWait:  time.Second,
	})
	if err != nil {
		t.Fatal(err)
	}
	started := time.Now()
	if _, err := client.Price(context.Background(), 501); !errors.Is(err, ErrUnavailable) {
		t.Fatalf("expected controlled timeout error, got %v", err)
	}
	if elapsed := time.Since(started); elapsed > 250*time.Millisecond {
		t.Fatalf("request exceeded timeout budget: %s", elapsed)
	}
}

func TestCancelledProbeDoesNotStickBreakerHalfOpen(t *testing.T) {
	now := time.Now()
	breaker := &circuitBreaker{threshold: 1, recovery: time.Second}
	breaker.record(false, now)
	if !breaker.allow(now.Add(2 * time.Second)) {
		t.Fatal("expected half-open probe")
	}
	breaker.release()
	if !breaker.allow(now.Add(2 * time.Second)) {
		t.Fatal("breaker stuck after cancelled probe")
	}
}
