package product

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"oms/internal/observability"
)

var ErrProductNotFound = errors.New("product not found")

// CatalogRepository loads active product prices from PostgreSQL.
type CatalogRepository struct {
	db *pgxpool.Pool
}

func NewCatalogRepository(db *pgxpool.Pool) *CatalogRepository {
	return &CatalogRepository{db: db}
}

// Price returns the unit price for an active product or ErrProductNotFound.
func (r *CatalogRepository) Price(ctx context.Context, productID int64) (float64, error) {
	ctx, end := observability.StartSpan(ctx, "product.catalog.price")
	defer end()
	const query = `SELECT unit_price FROM products WHERE id = $1 AND active = TRUE`
	var price float64
	err := r.db.QueryRow(ctx, query, productID).Scan(&price)
	if errors.Is(err, pgx.ErrNoRows) {
		return 0, ErrProductNotFound
	}
	if err != nil {
		return 0, fmt.Errorf("lookup product price: %w", err)
	}
	if price <= 0 {
		return 0, fmt.Errorf("invalid catalog price for product %d", productID)
	}
	return price, nil
}
