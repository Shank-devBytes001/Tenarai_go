//go:build integration

package orders

import (
	"context"
	"log/slog"
	"os"
	"testing"
	"time"

	"oms/internal/config"
	"oms/internal/database"
	"oms/internal/product"
)

func TestRepositoryAgainstPostgreSQL(t *testing.T) {
	cfg, err := config.LoadBase()
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	pool, err := database.Open(ctx, cfg)
	if err != nil {
		t.Skip("PostgreSQL unavailable:", err)
	}
	defer pool.Close()
	repo := NewSQLRepository(pool)
	service := NewService(repo, productClient(t, cfg))
	order, err := service.Create(ctx, CreateInput{CustomerID: 101, ProductID: 501, Quantity: 2})
	if err != nil {
		t.Fatal(err)
	}
	if order.UnitPrice != 12.5 || order.TotalAmount != 25 {
		t.Fatalf("unexpected pricing snapshot: %#v", order)
	}
	loaded, err := service.Get(ctx, order.ID)
	if err != nil {
		t.Fatal(err)
	}
	if loaded.Status != StatusCreated {
		t.Fatalf("status = %s", loaded.Status)
	}
}

func productClient(t *testing.T, cfg config.Config) product.Client {
	t.Helper()
	client, err := product.NewClient(cfg)
	if err != nil {
		t.Fatal(err)
	}
	if os.Getenv("PRODUCT_SERVICE_URL") == "" {
		t.Skip("PRODUCT_SERVICE_URL not set for integration test")
	}
	return client
}

func init() {
	slog.SetDefault(slog.New(slog.NewTextHandler(os.Stderr, nil)))
}
