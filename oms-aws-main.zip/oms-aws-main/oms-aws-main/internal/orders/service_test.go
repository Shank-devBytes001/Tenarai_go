package orders

import (
	"context"
	"errors"
	"testing"
	"time"
)

type fakeRepository struct {
	order *Order
}

func (r *fakeRepository) Create(_ context.Context, order *Order) error {
	order.ID = 1
	order.CreatedAt = time.Now()
	order.UpdatedAt = order.CreatedAt
	r.order = order
	return nil
}

func (r *fakeRepository) FindByID(_ context.Context, id int64) (*Order, error) {
	if r.order == nil || r.order.ID != id {
		return nil, ErrNotFound
	}
	return r.order, nil
}

func (r *fakeRepository) List(context.Context, int, int) ([]Order, error) {
	if r.order == nil {
		return []Order{}, nil
	}
	return []Order{*r.order}, nil
}

func (r *fakeRepository) UpdateStatus(_ context.Context, id int64, status Status) (*Order, error) {
	order, err := r.FindByID(context.Background(), id)
	if err != nil {
		return nil, err
	}
	order.Status = status
	return order, nil
}

type fakePrices struct {
	price float64
	err   error
}

func (p fakePrices) Price(context.Context, int64) (float64, error) {
	return p.price, p.err
}

func TestCreateValidatesAndSnapshotsProductPrice(t *testing.T) {
	repo := &fakeRepository{}
	service := NewService(repo, fakePrices{price: 12.50})
	order, err := service.Create(context.Background(), CreateInput{CustomerID: 101, ProductID: 501, Quantity: 2})
	if err != nil {
		t.Fatal(err)
	}
	if order.TotalAmount != 25 || order.UnitPrice != 12.5 || order.Status != StatusCreated {
		t.Fatalf("unexpected order: %#v", order)
	}
	if _, err := service.Create(context.Background(), CreateInput{CustomerID: 0, ProductID: 501, Quantity: 1}); !errors.Is(err, ErrInvalid) {
		t.Fatalf("expected invalid input, got %v", err)
	}
}

func TestCreateMapsProductDependencyFailure(t *testing.T) {
	service := NewService(&fakeRepository{}, fakePrices{err: errors.New("offline")})
	_, err := service.Create(context.Background(), CreateInput{CustomerID: 1, ProductID: 1, Quantity: 1})
	if !errors.Is(err, ErrDependency) {
		t.Fatalf("expected dependency error, got %v", err)
	}
}
