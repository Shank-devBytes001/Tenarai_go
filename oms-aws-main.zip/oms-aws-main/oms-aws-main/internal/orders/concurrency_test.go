package orders

import (
	"context"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

// TestConcurrentCreates verifies order creation remains safe under concurrent load.
func TestConcurrentCreates(t *testing.T) {
	repo := &concurrentRepository{}
	service := NewService(repo, fakePrices{price: 12.5})
	const workers = 100
	var wg sync.WaitGroup
	wg.Add(workers)
	var failures atomic.Int32
	for i := 0; i < workers; i++ {
		go func(customerID int64) {
			defer wg.Done()
			_, err := service.Create(context.Background(), CreateInput{
				CustomerID: customerID,
				ProductID:  501,
				Quantity:   1,
			})
			if err != nil {
				failures.Add(1)
			}
		}(int64(1000 + i))
	}
	wg.Wait()
	if failures.Load() > 0 {
		t.Fatalf("%d concurrent creates failed", failures.Load())
	}
	if got := repo.count(); got != workers {
		t.Fatalf("stored orders = %d, want %d", got, workers)
	}
}

type concurrentRepository struct {
	mu     sync.Mutex
	nextID int64
	items  []Order
}

func (r *concurrentRepository) Create(_ context.Context, order *Order) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.nextID++
	order.ID = r.nextID
	order.CreatedAt = time.Now().UTC()
	order.UpdatedAt = order.CreatedAt
	r.items = append(r.items, *order)
	return nil
}

func (r *concurrentRepository) FindByID(_ context.Context, id int64) (*Order, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	for i := range r.items {
		if r.items[i].ID == id {
			copy := r.items[i]
			return &copy, nil
		}
	}
	return nil, ErrNotFound
}

func (r *concurrentRepository) List(_ context.Context, limit, offset int) ([]Order, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	if offset >= len(r.items) {
		return []Order{}, nil
	}
	end := offset + limit
	if end > len(r.items) {
		end = len(r.items)
	}
	out := make([]Order, end-offset)
	copy(out, r.items[offset:end])
	return out, nil
}

func (r *concurrentRepository) UpdateStatus(_ context.Context, id int64, status Status) (*Order, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	for i := range r.items {
		if r.items[i].ID == id {
			r.items[i].Status = status
			copy := r.items[i]
			return &copy, nil
		}
	}
	return nil, ErrNotFound
}

func (r *concurrentRepository) count() int {
	r.mu.Lock()
	defer r.mu.Unlock()
	return len(r.items)
}
