package orders

import (
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"testing"

	"oms/internal/config"
)

func TestHealthLiveAndMetricsEndpoints(t *testing.T) {
	cfg := config.Config{JWTSecret: []byte("0123456789abcdef0123456789abcdef")}
	handler := NewHandler(cfg, slog.New(slog.NewTextHandler(io.Discard, nil)), NewService(&fakeRepository{}, fakePrices{price: 1}), nil)
	live := httptest.NewRequest(http.MethodGet, "/health/live", nil)
	liveRecorder := httptest.NewRecorder()
	handler.ServeHTTP(liveRecorder, live)
	if liveRecorder.Code != http.StatusOK {
		t.Fatalf("live status = %d", liveRecorder.Code)
	}
	metrics := httptest.NewRequest(http.MethodGet, "/metrics", nil)
	metricsRecorder := httptest.NewRecorder()
	handler.ServeHTTP(metricsRecorder, metrics)
	if metricsRecorder.Code != http.StatusOK {
		t.Fatalf("metrics status = %d", metricsRecorder.Code)
	}
}
