package orders

import (
	"context"
	"errors"
	"time"

	"oms/internal/observability"
)

var (
	ErrNotFound   = errors.New("order not found")
	ErrInvalid    = errors.New("invalid order")
	ErrDependency = errors.New("dependency unavailable")
)

type Status string

const (
	StatusCreated   Status = "CREATED"
	StatusConfirmed Status = "CONFIRMED"
	StatusCancelled Status = "CANCELLED"
)

func ValidStatus(status Status) bool {
	return status == StatusCreated || status == StatusConfirmed || status == StatusCancelled
}

type Order struct {
	ID          int64     `json:"id"`
	CustomerID  int64     `json:"customerId"`
	ProductID   int64     `json:"productId"`
	Quantity    int       `json:"quantity"`
	UnitPrice   float64   `json:"unitPrice"`
	TotalAmount float64   `json:"totalAmount"`
	Status      Status    `json:"status"`
	CreatedAt   time.Time `json:"createdAt"`
	UpdatedAt   time.Time `json:"updatedAt"`
}

type CreateInput struct {
	CustomerID int64 `json:"customerId"`
	ProductID  int64 `json:"productId"`
	Quantity   int   `json:"quantity"`
}

type Repository interface {
	Create(ctx context.Context, order *Order) error
	FindByID(ctx context.Context, id int64) (*Order, error)
	List(ctx context.Context, limit, offset int) ([]Order, error)
	UpdateStatus(ctx context.Context, id int64, status Status) (*Order, error)
}

type PriceClient interface {
	Price(ctx context.Context, productID int64) (float64, error)
}

type Service struct {
	repository Repository
	prices     PriceClient
}

func NewService(repository Repository, prices PriceClient) *Service {
	return &Service{repository: repository, prices: prices}
}

func (s *Service) Create(ctx context.Context, input CreateInput) (*Order, error) {
	ctx, end := observability.StartSpan(ctx, "orders.service.create")
	defer end()
	if input.CustomerID <= 0 || input.ProductID <= 0 || input.Quantity < 1 || input.Quantity > 10000 {
		return nil, ErrInvalid
	}
	price, err := s.prices.Price(ctx, input.ProductID)
	if err != nil {
		return nil, errors.Join(ErrDependency, err)
	}
	total := price * float64(input.Quantity)
	if total > 999999999999.99 {
		return nil, ErrInvalid
	}
	order := &Order{
		CustomerID:  input.CustomerID,
		ProductID:   input.ProductID,
		Quantity:    input.Quantity,
		UnitPrice:   price,
		TotalAmount: total,
		Status:      StatusCreated,
	}
	if err := s.repository.Create(ctx, order); err != nil {
		return nil, err
	}
	return order, nil
}

func (s *Service) Get(ctx context.Context, id int64) (*Order, error) {
	ctx, end := observability.StartSpan(ctx, "orders.service.get")
	defer end()
	if id <= 0 {
		return nil, ErrInvalid
	}
	return s.repository.FindByID(ctx, id)
}

func (s *Service) List(ctx context.Context, limit, offset int) ([]Order, error) {
	ctx, end := observability.StartSpan(ctx, "orders.service.list")
	defer end()
	if limit == 0 {
		limit = 50
	}
	if limit < 1 || limit > 100 || offset < 0 || offset > 100000 {
		return nil, ErrInvalid
	}
	return s.repository.List(ctx, limit, offset)
}

func (s *Service) UpdateStatus(ctx context.Context, id int64, status Status) (*Order, error) {
	ctx, end := observability.StartSpan(ctx, "orders.service.update_status")
	defer end()
	if id <= 0 || !ValidStatus(status) {
		return nil, ErrInvalid
	}
	return s.repository.UpdateStatus(ctx, id, status)
}
