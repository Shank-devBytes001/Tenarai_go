package orders

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"oms/internal/observability"
)

type SQLRepository struct {
	db *pgxpool.Pool
}

func NewSQLRepository(db *pgxpool.Pool) *SQLRepository {
	return &SQLRepository{db: db}
}

const orderColumns = `id, customer_id, product_id, quantity, unit_price, total_amount, status, created_at, updated_at`

func (r *SQLRepository) Create(ctx context.Context, order *Order) error {
	ctx, end := observability.StartSpan(ctx, "orders.repository.create")
	defer end()
	const query = `INSERT INTO orders (customer_id, product_id, quantity, unit_price, total_amount, status)
		VALUES ($1, $2, $3, $4, $5, $6) RETURNING ` + orderColumns
	if err := scanOrder(r.db.QueryRow(ctx, query, order.CustomerID, order.ProductID, order.Quantity, order.UnitPrice, order.TotalAmount, order.Status), order); err != nil {
		return fmt.Errorf("insert order: %w", err)
	}
	return nil
}

func (r *SQLRepository) FindByID(ctx context.Context, id int64) (*Order, error) {
	ctx, end := observability.StartSpan(ctx, "orders.repository.find_by_id")
	defer end()
	const query = `SELECT ` + orderColumns + ` FROM orders WHERE id = $1`
	order := new(Order)
	if err := scanOrder(r.db.QueryRow(ctx, query, id), order); err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, ErrNotFound
		}
		return nil, fmt.Errorf("find order: %w", err)
	}
	return order, nil
}

func (r *SQLRepository) List(ctx context.Context, limit, offset int) ([]Order, error) {
	ctx, end := observability.StartSpan(ctx, "orders.repository.list")
	defer end()
	const query = `SELECT ` + orderColumns + ` FROM orders ORDER BY created_at DESC, id DESC LIMIT $1 OFFSET $2`
	rows, err := r.db.Query(ctx, query, limit, offset)
	if err != nil {
		return nil, fmt.Errorf("list orders: %w", err)
	}
	defer rows.Close()
	orders := make([]Order, 0)
	for rows.Next() {
		var order Order
		if err := scanOrder(rows, &order); err != nil {
			return nil, fmt.Errorf("scan order: %w", err)
		}
		orders = append(orders, order)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate orders: %w", err)
	}
	return orders, nil
}

func (r *SQLRepository) UpdateStatus(ctx context.Context, id int64, status Status) (*Order, error) {
	ctx, end := observability.StartSpan(ctx, "orders.repository.update_status")
	defer end()
	const query = `UPDATE orders SET status = $2, updated_at = NOW() WHERE id = $1 RETURNING ` + orderColumns
	order := new(Order)
	if err := scanOrder(r.db.QueryRow(ctx, query, id, status), order); err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, ErrNotFound
		}
		return nil, fmt.Errorf("update order status: %w", err)
	}
	return order, nil
}

type scanner interface {
	Scan(dest ...any) error
}

func scanOrder(row scanner, order *Order) error {
	return row.Scan(&order.ID, &order.CustomerID, &order.ProductID, &order.Quantity, &order.UnitPrice, &order.TotalAmount, &order.Status, &order.CreatedAt, &order.UpdatedAt)
}
