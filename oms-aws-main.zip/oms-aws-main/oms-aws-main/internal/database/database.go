// Package database opens a pooled PostgreSQL connection and applies schema plus seed data.
package database

import (
	"context"
	_ "embed"
	"fmt"
	"net"
	"net/url"
	"strings"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"

	"oms/internal/config"
)

//go:embed schema.sql
var schema string

//go:embed seed.sql
var seed string

// Open connects to PostgreSQL, verifies connectivity, and initializes schema/seed statements.
func Open(ctx context.Context, cfg config.Config) (*pgxpool.Pool, error) {
	if cfg.DBUser == "" || cfg.DBPassword == "" {
		return nil, fmt.Errorf("DB_USER and DB_PASSWORD must be set")
	}
	dsn := (&url.URL{
		Scheme: "postgres",
		User:   url.UserPassword(cfg.DBUser, cfg.DBPassword),
		Host:   net.JoinHostPort(cfg.DBHost, cfg.DBPort),
		Path:   cfg.DBName,
	}).String()
	pool, err := pgxpool.New(ctx, dsn)
	if err != nil {
		return nil, fmt.Errorf("create PostgreSQL connection pool: %w", err)
	}
	if err := pool.Ping(ctx); err != nil {
		pool.Close()
		return nil, fmt.Errorf("ping PostgreSQL: %w", err)
	}
	if err := execScript(ctx, pool, schema); err != nil {
		pool.Close()
		return nil, err
	}
	if err := execScript(ctx, pool, seed); err != nil {
		pool.Close()
		return nil, err
	}
	return pool, nil
}

func execScript(ctx context.Context, pool *pgxpool.Pool, script string) error {
	scriptCtx, cancel := context.WithTimeout(ctx, 15*time.Second)
	defer cancel()
	for _, statement := range strings.Split(script, ";") {
		statement = strings.TrimSpace(statement)
		if statement == "" {
			continue
		}
		if _, err := pool.Exec(scriptCtx, statement); err != nil {
			return fmt.Errorf("execute database script: %w", err)
		}
	}
	return nil
}
