-- Idempotent catalog seed for local and integration environments.
INSERT INTO products (id, name, unit_price, active) VALUES
    (501, 'Industrial Widget', 12.50, TRUE),
    (502, 'Premium Gadget', 49.99, TRUE),
    (503, 'Economy Part', 3.25, TRUE)
ON CONFLICT (id) DO UPDATE SET
    name = EXCLUDED.name,
    unit_price = EXCLUDED.unit_price,
    active = EXCLUDED.active,
    updated_at = NOW();
