package config

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	awsconfig "github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/service/secretsmanager"
)

// hydrateFromSecretsManager overlays environment variables when AWS_SECRETS_MANAGER_SECRET_ID is set.
// Secret JSON keys should match environment variable names (for example DB_PASSWORD, JWT_SECRET).
func hydrateFromSecretsManager(ctx context.Context) error {
	secretID := os.Getenv("AWS_SECRETS_MANAGER_SECRET_ID")
	if secretID == "" {
		return nil
	}
	region := env("AWS_REGION", "us-east-1")
	loadCtx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()
	awsCfg, err := awsconfig.LoadDefaultConfig(loadCtx, awsconfig.WithRegion(region))
	if err != nil {
		return fmt.Errorf("load AWS configuration: %w", err)
	}
	client := secretsmanager.NewFromConfig(awsCfg)
	output, err := client.GetSecretValue(loadCtx, &secretsmanager.GetSecretValueInput{
		SecretId: aws.String(secretID),
	})
	if err != nil {
		return fmt.Errorf("read secret %s: %w", secretID, err)
	}
	payload := output.SecretString
	if payload == nil {
		return fmt.Errorf("secret %s has no string payload", secretID)
	}
	var values map[string]string
	if err := json.Unmarshal([]byte(*payload), &values); err != nil {
		return fmt.Errorf("parse secret JSON: %w", err)
	}
	for key, value := range values {
		if value == "" {
			continue
		}
		if os.Getenv(key) == "" {
			if err := os.Setenv(key, value); err != nil {
				return fmt.Errorf("set env %s from secret: %w", key, err)
			}
		}
	}
	return nil
}
