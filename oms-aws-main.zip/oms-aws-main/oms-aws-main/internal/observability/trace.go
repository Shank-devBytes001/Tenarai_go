package observability

import (
	"context"
	"log/slog"
	"time"
)

type spanKey struct{}

// Span carries a logical operation name through the call stack for structured logs.
type Span struct {
	Name  string
	Start time.Time
}

// WithLogger attaches a logger to the context for span completion logs.
func WithLogger(ctx context.Context, logger *slog.Logger) context.Context {
	return context.WithValue(ctx, loggerKey{}, logger)
}

type loggerKey struct{}

func loggerFrom(ctx context.Context) *slog.Logger {
	if logger, ok := ctx.Value(loggerKey{}).(*slog.Logger); ok && logger != nil {
		return logger
	}
	return slog.Default()
}

// StartSpan begins a request-flow span. Call the returned function when the operation finishes.
func StartSpan(ctx context.Context, name string) (context.Context, func()) {
	span := Span{Name: name, Start: time.Now()}
	ctx = context.WithValue(ctx, spanKey{}, append(spansFrom(ctx), span))
	return ctx, func() {
		finished := time.Since(span.Start)
		logger := loggerFrom(ctx)
		attrs := []any{
			"span", name,
			"request_id", RequestID(ctx),
			"duration", finished.String(),
		}
		logger.Info("span finished", attrs...)
	}
}

func spansFrom(ctx context.Context) []Span {
	spans, _ := ctx.Value(spanKey{}).([]Span)
	return spans
}
