// Token CLI mints HS256 JWTs for local and integration testing.
package main

import (
	"flag"
	"fmt"
	"os"
	"time"

	"github.com/joho/godotenv"

	"oms/internal/auth"
)

func main() {
	subject := flag.String("subject", "", "JWT subject")
	role := flag.String("role", auth.RoleCustomer, "JWT role: customer or admin")
	flag.Parse()
	if err := godotenv.Load(); err != nil && !os.IsNotExist(err) {
		fmt.Fprintln(os.Stderr, "load .env:", err)
		os.Exit(1)
	}
	secret := []byte(os.Getenv("JWT_SECRET"))
	if len(secret) < 32 {
		fmt.Fprintln(os.Stderr, "JWT_SECRET must contain at least 32 bytes")
		os.Exit(1)
	}
	ttl := 15 * time.Minute
	if configured := os.Getenv("JWT_TTL"); configured != "" {
		parsed, err := time.ParseDuration(configured)
		if err != nil || parsed <= 0 {
			fmt.Fprintln(os.Stderr, "JWT_TTL must be a positive duration")
			os.Exit(1)
		}
		ttl = parsed
	}
	token, err := auth.IssueToken(secret, *subject, *role, ttl)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	fmt.Println(token)
}
