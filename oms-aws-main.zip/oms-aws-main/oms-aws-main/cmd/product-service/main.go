// Product Service exposes catalog prices from PostgreSQL for the Order Service.
package main

import (
	"context"
	"errors"
	"io"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"strconv"
	"syscall"
	"time"

	"github.com/gin-gonic/gin"

	"oms/internal/config"
	"oms/internal/database"
	"oms/internal/observability"
	"oms/internal/product"
)

func main() {
	cfg, err := config.LoadBase()
	if err != nil {
		slog.Error("load configuration", "error", err)
		os.Exit(1)
	}
	logger := observability.NewLogger(cfg.LogLevel)
	gin.SetMode(gin.ReleaseMode)
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	db, err := database.Open(ctx, cfg)
	cancel()
	if err != nil {
		logger.Error("connect to database", "error", err)
		os.Exit(1)
	}
	defer db.Close()
	catalog := product.NewCatalogRepository(db)
	port := env("PRODUCT_SERVICE_PORT", "8082")
	metrics := observability.NewMetrics("oms_product_service")
	router := gin.New()
	router.Use(gin.CustomRecoveryWithWriter(io.Discard, func(c *gin.Context, _ any) {
		logger.Error("product handler panic", "request_id", observability.RequestID(c.Request.Context()), "method", c.Request.Method, "path", c.Request.URL.Path)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "internal server error"})
		c.Abort()
	}))
	router.GET("/health/live", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"status": "UP"})
	})
	router.GET("/health/ready", func(c *gin.Context) {
		pingCtx, pingCancel := context.WithTimeout(c.Request.Context(), 2*time.Second)
		defer pingCancel()
		if err := db.Ping(pingCtx); err != nil {
			metrics.DatabaseError()
			c.JSON(http.StatusServiceUnavailable, gin.H{"status": "NOT_READY"})
			return
		}
		c.JSON(http.StatusOK, gin.H{"status": "READY"})
	})
	router.GET("/metrics", gin.WrapH(metrics.Handler()))
	router.GET("/internal/products/:id/price", func(c *gin.Context) {
		id, err := strconv.ParseInt(c.Param("id"), 10, 64)
		if err != nil || id <= 0 {
			c.JSON(http.StatusBadRequest, gin.H{"error": "invalid product id"})
			return
		}
		price, err := catalog.Price(c.Request.Context(), id)
		if errors.Is(err, product.ErrProductNotFound) {
			c.JSON(http.StatusNotFound, gin.H{"error": "product not found"})
			return
		}
		if err != nil {
			metrics.DatabaseError()
			logger.Error("catalog lookup failed", "request_id", observability.RequestID(c.Request.Context()), "error", err)
			c.JSON(http.StatusInternalServerError, gin.H{"error": "internal server error"})
			return
		}
		c.JSON(http.StatusOK, struct {
			ProductID int64   `json:"productId"`
			Price     float64 `json:"price"`
		}{ProductID: id, Price: price})
	})
	server := &http.Server{
		Addr:              ":" + port,
		Handler:           metrics.Middleware(logger, router),
		ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout:       10 * time.Second,
		WriteTimeout:      10 * time.Second,
		IdleTimeout:       60 * time.Second,
	}
	go func() {
		logger.Info("product service listening", "port", port)
		if err := server.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			logger.Error("product service failed", "error", err)
			os.Exit(1)
		}
	}()
	stop := make(chan os.Signal, 1)
	signal.Notify(stop, syscall.SIGINT, syscall.SIGTERM)
	<-stop
	shutdownCtx, shutdownCancel := context.WithTimeout(context.Background(), cfg.ShutdownTimeout)
	defer shutdownCancel()
	if err := server.Shutdown(shutdownCtx); err != nil {
		logger.Error("product service shutdown failed", "error", err)
	}
}

func env(key, fallback string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return fallback
}
