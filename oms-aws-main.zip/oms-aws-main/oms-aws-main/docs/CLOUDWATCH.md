# CloudWatch integration

This project emits **JSON logs on stderr** and **Prometheus metrics** on `/metrics`. On AWS Elastic Beanstalk or EC2:

## Application logs

1. Install the [CloudWatch Agent](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/Install-CloudWatch-Agent.html) on each instance.
2. Tail stderr from the process manager (systemd/Procfile runner) or redirect service output to a file such as `/var/log/oms/gateway.log`.
3. Configure the agent to ship that file to a log group, for example `/oms/gateway`.

Log records include `request_id`, `method`, `path`, `status`, `duration`, and span completion events (`span finished`) for handler → service → repository → PostgreSQL flow correlation.

## Metrics

1. Scrape `http://<instance>:8080/metrics` (gateway) and private service ports from a Prometheus server, **or**
2. Use the CloudWatch Agent [Prometheus plugin](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/CloudWatch-Agent-PrometheusEC2.html) to remote-write counters and histograms:
   - `oms_gateway_http_requests_total`
   - `oms_gateway_http_request_duration_seconds`
   - `oms_order_service_database_errors_total`

## Alarms (recommended)

- Gateway 5xx rate from `oms_gateway_http_errors_total`
- Order service database errors from `oms_order_service_database_errors_total`
- Elastic Beanstalk environment health `Severe`

## Secrets

Store `DB_PASSWORD`, `JWT_SECRET`, and related keys in **AWS Secrets Manager**. Set `AWS_SECRETS_MANAGER_SECRET_ID` and `AWS_REGION` on each EB environment so services hydrate environment variables at startup (see README).
